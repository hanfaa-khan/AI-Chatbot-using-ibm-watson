import os
import git
import shutil
from dotenv import load_dotenv
# --- UPDATED IMPORTS ---
from langchain_community.document_loaders import TextLoader
from langchain_community.vectorstores import FAISS
# --- END UPDATED IMPORTS ---
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.memory import ConversationBufferMemory
from langchain.chains import ConversationalRetrievalChain
from langchain_ibm import WatsonxEmbeddings, WatsonxLLM
from ibm_watsonx_ai.metanames import EmbedTextParamsMetaNames, GenTextParamsMetaNames as GenParams
from ibm_watsonx_ai.foundation_models.utils.enums import DecodingMethods

from prompts_llama3 import model_prompt, custom_question_prompt

load_dotenv()

# Restrict to only markdown files for strict documentation Q&A
allowed_extensions = [".md"]


class Embedder:
    def __init__(self, git_link) -> None:
        self.git_link = git_link
        last_name = self.git_link.split("/")[-1]
        self.clone_path = last_name.split(".")[0]

    def clone_repo(self):
        if not os.path.exists(self.clone_path):
            git.Repo.clone_from(self.git_link, self.clone_path)

    # In utils.py

    def extract_all_files(self):
        root_dir = self.clone_path
        docs = []
        for dirpath, dirnames, filenames in os.walk(root_dir):
            for file in filenames:
                file_extension = os.path.splitext(file)[1]
                if file_extension in allowed_extensions:
                    try:
                        # --- MODIFICATION START ---
                        file_path = os.path.join(dirpath, file)
                        # Create a user-friendly relative path
                        relative_path = os.path.relpath(file_path, root_dir)
                        
                        loader = TextLoader(file_path, encoding="utf-8")
                        # Load documents from the file
                        file_docs = loader.load() 
                        
                        # Add the clean relative_path to each document's metadata
                        for doc in file_docs:
                            doc.metadata["source"] = relative_path
                        
                        docs.extend(file_docs)
                        # --- MODIFICATION END ---
                    except Exception as e:
                        print(f"Error loading file {file}: {e}")
                        pass
        return docs

    def chunk_files(self, docs):
        text_splitter = RecursiveCharacterTextSplitter(
            separators=["\n\n", "\n", " ", ""], chunk_size=1000, chunk_overlap=200
        )
        chunked_documents = text_splitter.split_documents(docs)
        print(f"Successfully split documents into {len(chunked_documents)} chunks.")
        return chunked_documents

    def delete_directory(self, path):
        if os.path.exists(path):
            shutil.rmtree(path)
            print(f"Successfully deleted directory: {path}")

    def get_conversation_chain(self, watsonx_api_key):
        docs = self.extract_all_files()
        chunked_documents = self.chunk_files(docs)
        
        embed_params = {EmbedTextParamsMetaNames.TRUNCATE_INPUT_TOKENS: 3}
        embeddings = WatsonxEmbeddings(
            model_id=os.getenv("EMBEDDING_MODEL_ID"),
            url=os.getenv("ENDPOINT_URL"),
            apikey=watsonx_api_key,
            project_id=os.getenv("PROJECT_ID"),
            params=embed_params,
        )
        
        vector_store = FAISS.from_documents(
            documents=chunked_documents, embedding=embeddings
        )
        retriever = vector_store.as_retriever(search_kwargs={"k": 5})

        memory = ConversationBufferMemory(
            memory_key="chat_history", return_messages=True, output_key='answer'
        )

        qa_chain_prompt = model_prompt()
        question_generator_prompt = custom_question_prompt()

        parameters = {
            GenParams.DECODING_METHOD: DecodingMethods.GREEDY,
            GenParams.MAX_NEW_TOKENS: 2048,
            GenParams.MIN_NEW_TOKENS: 1,
            GenParams.TEMPERATURE: 0.0,
            GenParams.REPETITION_PENALTY: 1.1,
        }
        
        llm = WatsonxLLM(
            model_id=os.getenv("PROMPT_MODEL_ID"),
            url=os.getenv("ENDPOINT_URL"),
            apikey=watsonx_api_key,
            project_id=os.getenv("PROJECT_ID"),
            params=parameters,
        )
        
        conversation_chain = ConversationalRetrievalChain.from_llm(
            llm=llm,
            retriever=retriever,
            memory=memory,
            chain_type="stuff",
            combine_docs_chain_kwargs={"prompt": qa_chain_prompt},
            condense_question_prompt=question_generator_prompt,
            return_source_documents=True,
            verbose=False,
        )
        
        self.delete_directory(self.clone_path)
        return conversation_chain

    def retrieve_results(self, query, conversation_chain):
        
        result = conversation_chain.invoke({"question": query})
        return result