import streamlit as st
import utils
import time
import os

# Configure page with enhanced settings
st.set_page_config(
    page_title="WatsonBot - AI Code Assistant",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded",
    menu_items={
        'Get Help': 'https://github.com/your-repo/help',
        'Report a bug': "https://github.com/your-repo/issues",
        'About': "# WatsonBot\nYour AI-powered GitHub repository assistant powered by IBM WatsonX!"
    }
)

def apply_custom_css():
    """Apply modern CSS styling"""
    st.markdown("""
    <style>
    /* Import Google Fonts */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
    
    /* Global styles */
    .stApp {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        font-family: 'Inter', sans-serif;
    }
    
    /* Header styling */
    .main-header {
        background: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(20px);
        padding: 2rem;
        border-radius: 20px;
        margin-bottom: 2rem;
        border: 1px solid rgba(255, 255, 255, 0.2);
        text-align: center;
    }
    
    .main-title {
        font-size: 3rem;
        font-weight: 700;
        color: white;
        margin: 0;
        text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    }
    
    .main-subtitle {
        font-size: 1.2rem;
        color: rgba(255, 255, 255, 0.9);
        margin-top: 0.5rem;
        font-weight: 300;
    }
    
    /* Sidebar styling */
    .css-1d391kg {
        background: linear-gradient(180deg, #2c3e50 0%, #34495e 100%);
        border-right: 2px solid rgba(255, 255, 255, 0.1);
    }
    
    .sidebar-header {
        text-align: center;
        padding: 1rem;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 15px;
        margin-bottom: 1.5rem;
    }
    
    .sidebar-title {
        color: #ecf0f1;
        font-size: 1.5rem;
        font-weight: 600;
        margin: 0;
    }
    
    .sidebar-description {
        color: rgba(236, 240, 241, 0.8);
        font-size: 0.9rem;
        line-height: 1.5;
        margin-top: 1rem;
    }
    
    /* Input styling */
    .stTextInput > div > div > input {
        background: rgba(255, 255, 255, 0.1);
        color: white;
        border: 2px solid rgba(255, 255, 255, 0.3);
        border-radius: 12px;
        padding: 12px 16px;
        backdrop-filter: blur(10px);
        font-size: 0.95rem;
    }
    
    .stTextInput > div > div > input:focus {
        border-color: #667eea;
        box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.2);
        outline: none;
    }
    
    .stTextInput > label {
        color: white !important;
        font-weight: 500;
        margin-bottom: 8px;
    }
    
    /* Button styling */
    .stButton > button {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
        border-radius: 12px;
        padding: 12px 24px;
        font-weight: 600;
        font-size: 0.95rem;
        transition: all 0.3s ease;
        width: 100%;
        margin: 8px 0;
    }
    
    .stButton > button:hover {
        background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
    }
    
    /* Chat message styling */
    .stChatMessage {
        background: rgba(255, 255, 255, 0.1);
        border-radius: 15px;
        padding: 1rem;
        margin: 0.5rem 0;
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    /* Repository status card */
    .repo-status {
        background: rgba(255, 255, 255, 0.1);
        padding: 1.5rem;
        border-radius: 15px;
        margin: 1rem 0;
        border: 1px solid rgba(255, 255, 255, 0.2);
        backdrop-filter: blur(10px);
    }
    
    .repo-url {
        color: #f39c12;
        font-weight: 600;
        word-break: break-all;
    }
    
    .status-success {
        color: #2ecc71;
        font-weight: 600;
    }
    
    .progress-container {
        background: rgba(255, 255, 255, 0.1);
        border-radius: 15px;
        padding: 1.5rem;
        margin: 1rem 0;
        text-align: center;
    }
    
    .progress-title {
        color: white;
        font-weight: 600;
        margin-bottom: 1rem;
    }

    .metric-container {
        background: rgba(255, 255, 255, 0.1);
        padding: 1rem;
        border-radius: 12px;
        text-align: center;
        margin: 0.5rem;
    }
    
    .metric-value {
        font-size: 2rem;
        font-weight: 700;
        color: white;
    }
    
    .metric-label {
        font-size: 0.9rem;
        color: rgba(255, 255, 255, 0.8);
        margin-top: 0.5rem;
    }
    </style>
    """, unsafe_allow_html=True)

def display_header():
    """Display the main header"""
    st.markdown("""
    <div class="main-header">
        <h1 class="main-title">🤖 WatsonBot</h1>
        <p class="main-subtitle">Your AI-Powered GitHub Repository Assistant</p>
    </div>
    """, unsafe_allow_html=True)

def display_sidebar():
    """Enhanced sidebar that automatically handles API key from .env file."""
    with st.sidebar:
        st.markdown("""
        <div class="sidebar-header">
            <h2 class="sidebar-title">🚀 Configuration</h2>
            <p class="sidebar-description">
                WatsonBot analyzes GitHub repositories using IBM WatsonX AI. 
                Enter a repository URL below to get started.
            </p>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("---")
        st.markdown("### 📁 Repository Settings")
        
        if "user_repo" not in st.session_state:
            user_repo = st.text_input(
                "GitHub Repository URL",
                placeholder="https://github.com/username/repository",
                help="Enter the URL of a public GitHub repository"
            )
            
            if user_repo and not user_repo.startswith("https://github.com/"):
                st.warning("⚠️ Please enter a valid GitHub URL")
                st.stop()
            
            if not user_repo:
                st.info("📝 Please add a GitHub repository URL to continue.")
                st.stop()
            
            st.session_state.user_repo = user_repo
        else:
            st.success("✅ Repository: Connected")
            st.markdown(f"""
            <div style="background: rgba(255,255,255,0.1); padding: 0.5rem; border-radius: 8px; margin: 0.5rem 0;">
                <small style="color: rgba(255,255,255,0.8);">Current Repository:</small><br>
                <code style="color: #f39c12;">{st.session_state.user_repo}</code>
            </div>
            """, unsafe_allow_html=True)
            
            if st.button("🔄 Change Repository"):
                keys_to_clear = ["user_repo", "embedder", "conversation_chain", "messages"]
                for key in keys_to_clear:
                    if key in st.session_state:
                        del st.session_state[key]
                st.rerun()
        
        if "embedder" not in st.session_state and "watsonx_api_key" in st.session_state:
            st.markdown("---")
            st.markdown("### 🔧 Processing Repository")
            
            with st.spinner("🌀 Initializing repository analysis..."):
                try:
                    embedder = utils.Embedder(st.session_state.user_repo)
                    embedder.clone_repo()
                    st.session_state.embedder = embedder
                    st.toast("✅ Repository cloned successfully!")
                except Exception as e:
                    st.error(f"❌ Failed to clone repository: {str(e)}")
                    del st.session_state["user_repo"]
                    st.rerun()
            
            with st.spinner("🧠 Creating AI knowledge base..."):
                try:
                    st.session_state.conversation_chain = (
                        st.session_state.embedder.get_conversation_chain(
                            watsonx_api_key=st.session_state.watsonx_api_key
                        )
                    )
                    st.success("🎉 Repository analysis complete!")
                    st.toast("🚀 WatsonBot is ready to assist you!")
                except Exception as e:
                    st.error(f"❌ Failed to process repository: {str(e)}")
                    del st.session_state["user_repo"]
                    st.rerun()
        
        st.markdown("---")
        st.markdown("### 🎮 Actions")
        
        col1, col2 = st.columns(2)
        with col1:
            if st.button("🗑️ Clear Chat", help="Clear conversation history"):
                if "messages" in st.session_state:
                    clear_chat_history()
        
        with col2:
            if st.button("🔄 Refresh", help="Refresh the application"):
                st.rerun()

def display_repository_status():
    """Display current repository status"""
    if "user_repo" in st.session_state:
        st.markdown(f"""
        <div class="repo-status">
            <h3 style="color: white; margin: 0 0 1rem 0;">📊 Repository Status</h3>
            <p style="margin: 0.5rem 0; color: rgba(255,255,255,0.9);">
                <strong>🔗 Connected Repository:</strong><br>
                <span class="repo-url">{st.session_state.user_repo}</span>
            </p>
            <p style="margin: 0.5rem 0; color: rgba(255,255,255,0.9);">
                <strong>🤖 AI Status:</strong> 
                <span class="status-success">Ready for Questions</span>
            </p>
        </div>
        """, unsafe_allow_html=True)

def initialize_chat_history():
    """Initialize chat with a welcoming message"""
    if "messages" not in st.session_state:
        st.session_state.messages = [{
            "role": "assistant",
            "content": "👋 **Hello! I'm WatsonBot.**\n\nI've analyzed the documentation in this repository. What would you like to know?"
        }]

def clear_chat_history():
    """Clear chat history with improved messaging"""
    st.session_state.messages = [{
        "role": "assistant",
        "content": "🔄 **Chat History Cleared!** I'm ready for new questions."
    }]


def display_chat_interface():
    
    
    # --- PART 1: DISPLAY EXISTING CHAT HISTORY ---
    # This loop reads the session state and displays all previous messages.
    # It's updated to handle the new source data structure.
    for message in st.session_state.messages:
        with st.chat_message(message["role"], avatar="🧑‍💻" if message["role"] == "user" else "🤖"):
            st.markdown(message["content"])
            # If the message is from the assistant and has sources, display them.
            if message["role"] == "assistant" and "sources" in message and message["sources"]:
                with st.expander("📚 View Sources"):
                    # Iterate through the list of source dictionaries
                    for source_item in message["sources"]:
                        # Each 'source_item' is a dictionary: {'source': 'filename', 'content': '...'}
                        st.markdown(f"**Source File:** `{source_item['source']}`")
                        st.code(source_item['content'], language="markdown")

    # --- PART 2: HANDLE NEW USER INPUT ---
    # This block runs when the user types a new message.
    if prompt := st.chat_input("💬 Ask me anything about the repository docs..."):
        # Add and display the user's message
        st.session_state.messages.append({"role": "user", "content": prompt})
        with st.chat_message("user", avatar="🧑‍💻"):
            st.markdown(prompt)

        # Get and process the assistant's response
        with st.chat_message("assistant", avatar="🤖"):
            with st.spinner("🤔 Analyzing repository docs..."):
                try:
                    # Retrieve results from the conversation chain
                    result = st.session_state.embedder.retrieve_results(
                        prompt, st.session_state.conversation_chain
                    )
                    response_text = result["answer"]
                    source_docs = result.get("source_documents", [])
                    
                    # Display the main text answer
                    st.markdown(response_text)
                    
                    # Prepare the message to be stored in session state
                    assistant_message = {"role": "assistant", "content": response_text}
                    
                    # If there are source documents, process and store them
                    if source_docs:
                        # Create a list to hold our structured source data
                        sources_with_metadata = []
                        for doc in source_docs:
                            # Create a dictionary for each source with its filename and content
                            sources_with_metadata.append({
                                "source": doc.metadata.get("source", "Unknown Source"),
                                "content": doc.page_content
                            })

                        # Add the structured source data to our assistant message
                        assistant_message["sources"] = sources_with_metadata
                        
                        # Immediately display the sources for the new response
                        with st.expander("📚 View Sources"):
                            for source_item in sources_with_metadata:
                                st.markdown(f"**Source File:** `{source_item['source']}`")
                                st.code(source_item['content'], language="markdown")

                    # Add the complete assistant message (with sources) to the chat history
                    st.session_state.messages.append(assistant_message)
                
                except Exception as e:
                    # Handle any errors during AI processing
                    error_msg = f"❌ **An error occurred**: {str(e)}"
                    st.error(error_msg)
                    st.session_state.messages.append({"role": "assistant", "content": error_msg})

def display_metrics():
    """Display usage metrics"""
    if "messages" in st.session_state:
        col1, col2, col3 = st.columns(3)
        with col1:
            st.markdown(f'<div class="metric-container"><div class="metric-value">{len(st.session_state.messages)}</div><div class="metric-label">Total Messages</div></div>', unsafe_allow_html=True)
        with col2:
            user_messages = len([m for m in st.session_state.messages if m["role"] == "user"])
            st.markdown(f'<div class="metric-container"><div class="metric-value">{user_messages}</div><div class="metric-label">Your Questions</div></div>', unsafe_allow_html=True)
        with col3:
            st.markdown('<div class="metric-container"><div class="metric-value">✅</div><div class="metric-label">AI Status</div></div>', unsafe_allow_html=True)

def main():
    apply_custom_css()

    if "watsonx_api_key" not in st.session_state:
        try:
            from dotenv import load_dotenv
            load_dotenv()
            api_key = os.getenv("WATSONX_API_KEY")
            if not api_key:
                st.error("🚨 WatsonX API Key not found! Please add `WATSONX_API_KEY` to your .env file.")
                st.stop()
            st.session_state.watsonx_api_key = api_key
        except Exception as e:
            st.error(f"🚨 Error loading API key: {e}")
            st.stop()

    display_header()
    display_sidebar()
    
    if "embedder" in st.session_state and "conversation_chain" in st.session_state:
        display_repository_status()
        display_metrics()
        initialize_chat_history()
        display_chat_interface()
    else:
        st.markdown("""
        <div class="progress-container">
            <div class="progress-title">🚀 Welcome to WatsonBot!</div>
            <p style="color: rgba(255,255,255,0.8);">Please provide a GitHub repository URL in the sidebar to get started.</p>
        </div>
        """, unsafe_allow_html=True)

if __name__ == "__main__":
    main()